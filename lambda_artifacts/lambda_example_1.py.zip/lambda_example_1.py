# print mda
print('Hello lambda 1')